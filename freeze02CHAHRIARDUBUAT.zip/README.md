Sujet du projet : http://tdinfo.phelma.grenoble-inp.fr/



Comment utiliser le programme:
_make
_lancer astarte
_spécifier les sommets de départ et d'arrivée
_le programme afficher le chemin et le cout total


En cas de problème:

_si le graphe ne s'ouvre pas, vérifier "repertoire" au début du fichier astarte.c l'éditer et executer "make" dans le terminal pour générer un nouveau astarte executable.
_de la même facon on peut charger d'autres graphes de même forme en éditant le repertoire

